/**
 * Created by john on 7/23/17.
 */
const express = require('express');
const app = express();
var dotenv = require('dotenv');
dotenv.load();
var changeCase = require('change-case');
var commands = require('./commands');
var bitcoin = require('bitcoin');
var _ = require('underscore');

var e = module.exports;
e.ENV = process.env.NODE_ENV || 'production';

var bitclient = new bitcoin.Client({
    host: process.env.RISE_HOST,
    port: process.env.RISE_PORT,
    user: process.env.RISE_USER,
    pass: process.env.RISE_PASS,
    timeout: 30000
});

app.get('/', function (req, res) {
    bitclient.getInfo(function(err, balance, resHeaders) {
        if (err) return console.log(err);

        res.status(200).json(balance);
    });
});

app.listen(3000, function () {
    console.log('Example app listening on port 3000!')
});